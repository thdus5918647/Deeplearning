"use strict"

const port = 7002;
const express = require("express");
const app = express();

const mysql = require("mysql");
const connection = mysql.createConnection({ // 연결할 DB 정의
    host : "127.0.0.1",
    user : "wifiscanTEST",
    password : "@inlab515",
    database : "Network_Status"
});

let sql;
let insert_params;

connection.connect();

// 요청해독을 초기화 (default : utf-8)
app.use(express.urlencoded({extended: false}));

// 요청 해독을 json으로 진행
app.use(express.json());

// 요청 데이터를 분석하는 미들웨어
// 미들웨어란 애플리케이션 로직과의 데이터 교환 전에 대기, 분석, 필터링 및 HTTP통신을 다루는 코드를 일컫는 일반적인 용어
app.use(function(req, res, next){
    console.log(req.body);
    console.log(req.query);

    if(req.body.Cycle == 5){
        sql = "INSERT INTO AP_data_5sec(number, SSID, RSSI, Kbps, Frequency, BSSID, Time1, Time2, Cycle) VALUES(?,?,?,?,?,?,?,?,?)"
        insert_params = [, req.body.SSID, req.body.RSSI, req.body.Kbps, req.body.Frequency, req.body.BSSID, req.body.Time1, req.body.Time2, req.body.Cycle];
        connection.query(sql, insert_params, function(err, rows, fields){
            if(err) console.log(err);
            else console.log("insert success");
        });
    }else if(req.body.Cycle == 10){
        sql = "INSERT INTO AP_data_10sec(number, SSID, RSSI, Kbps, Frequency, BSSID, Time1, Time2, Cycle) VALUES(?,?,?,?,?,?,?,?,?)"
        insert_params = [, req.body.SSID, req.body.RSSI, req.body.Kbps, req.body.Frequency, req.body.BSSID, req.body.Time1, req.body.Time2, req.body.Cycle];
        connection.query(sql, insert_params, function(err, rows, fields){
            if(err) console.log(err);
            else console.log("insert success");
        });
    }else if(req.body.Cycle == 15){
        sql = "INSERT INTO AP_data_15sec(number, SSID, RSSI, Kbps, Frequency, BSSID, Time1, Time2, Cycle) VALUES(?,?,?,?,?,?,?,?,?)"
        insert_params = [, req.body.SSID, req.body.RSSI, req.body.Kbps, req.body.Frequency, req.body.BSSID, req.body.Time1, req.body.Time2, req.body.Cycle];
        connection.query(sql, insert_params, function(err, rows, fields){
            if(err) console.log(err);
            else console.log("insert success");
        });
    }

    next();
});

// POST 라우트
app.post("/", function(req, res){
    console.log("\npost");

    res.send("HTTP POST Successful\n");
});

// GET 라우트
app.get("/", function(req, res){
    console.log("\nget");
    
    res.send("HTTP GET Successful\n");
});

// 서버실행
app.listen(port, function(){
    console.log("Server port : ", port);
});
